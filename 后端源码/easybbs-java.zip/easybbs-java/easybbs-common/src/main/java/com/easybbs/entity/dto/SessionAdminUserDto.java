package com.easybbs.entity.dto;

public class SessionAdminUserDto {
    private String account;

    public void setAccount(String account) {
        this.account = account;
    }

    public String getAccount() {
        return account;
    }
}
