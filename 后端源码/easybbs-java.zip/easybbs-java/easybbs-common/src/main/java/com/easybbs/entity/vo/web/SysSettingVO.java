package com.easybbs.entity.vo.web;

public class SysSettingVO {
    private Boolean commentOpen;

    public Boolean getCommentOpen() {
        return commentOpen;
    }

    public void setCommentOpen(Boolean commentOpen) {
        this.commentOpen = commentOpen;
    }
}
